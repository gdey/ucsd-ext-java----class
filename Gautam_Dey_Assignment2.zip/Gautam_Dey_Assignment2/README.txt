
To run the command line version use:
java AnimalFarm

To run the GUI version use:
java GUIAnimalFarm

