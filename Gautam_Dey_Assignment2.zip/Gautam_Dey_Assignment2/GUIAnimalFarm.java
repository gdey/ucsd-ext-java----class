/***********
 * Name: Gautam Dey <gdey@anonymizerinc.com>
 * Date: Sunday, 17 Aug 2008
 * Assignment: 2
 * Class: Java Programming ][
 * Instructor: Farid Naisan
 */
public class GUIAnimalFarm extends Object
{
	/**
	 * The main method stats the application by calling the
	 *  start method of the UserInterface object.
	 */
	public static void main(String[] args ) {
		GUIUserInterface fw = new GUIUserInterface();
	}
}
