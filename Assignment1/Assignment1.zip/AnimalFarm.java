/***********
 * Name: Gautam Dey <gdey@anonymizerinc.com>
 * Date: Sunday, 3 Aug 2008
 * Assignment: 1
 * Class: Java Programming ][
 * Instructor: Farid Naisan
 */
public class AnimalFarm extends Object
{
	/**
	 * The main method stats the application by calling the
	 *  start method of the UserInterface object.
	 */
	public static void main(String[] args ) {
		UserInterface prog = new UserInterface();
		prog.start();
	}
}
